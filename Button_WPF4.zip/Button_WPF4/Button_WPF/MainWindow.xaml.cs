﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Button_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Button btn = new Button();
            btn.Click += Btn_Click;
            btn.Content = "OK";
            gridButton1.Children.Add(btn);

            //TextBlock txbl1 = new TextBlock();
            //txbl1.Text = "Quý chan";
            //btn.Content = txbl1;
            
            //TextBox tb = new TextBox();
            //tb.Width = 100;
            //tb.Height = 50;
            //btn.Content = tb;
        }

        //event click hiển thị messagebox
        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Click nè cu");
        }
    }
}