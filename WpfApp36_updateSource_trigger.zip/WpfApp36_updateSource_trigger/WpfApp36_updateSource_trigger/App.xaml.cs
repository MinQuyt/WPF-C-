﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfApp36_updateSource_trigger
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
