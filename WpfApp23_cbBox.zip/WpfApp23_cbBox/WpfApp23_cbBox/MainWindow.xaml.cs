﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp23_cbBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

           private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            List<Food> listName = new List<Food>()
            {
                new Food() { Name = "Gà cháy tỏi", Price = "200.000" },
                new Food() { Name = "Gà chiên mắm", Price = "150.000" },
                new Food() { Name = "Gà hầm thuốc bắc", Price = "199.000" }
            };

            cbBox.ItemsSource = listName;
            //cbBox.DisplayMemberPath = "Name";
            cbBox.SelectionChanged += cbBox_SelectionChanged;
            cbBox.SelectedValue = "Name";

            cbColor.ItemsSource = typeof(Colors).GetProperties(); 

           // cbFont.ItemsSource = typeof(FontFamily).GetProperties();    
        }

        private void cbBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbBox.SelectedItem is Food selectedFood)
            {
                // MessageBox.Show($"Selected Food: {selectedFood.Name}, Price: {selectedFood.Price}");
                MessageBox.Show(cbBox.SelectedValue.ToString());
            }
        }

        public class Food
        {
            public string Name { get; set; }
            public string Price { get; set; }

            public override string ToString()
            {
                return Name;
            }
        }
    }
}

    