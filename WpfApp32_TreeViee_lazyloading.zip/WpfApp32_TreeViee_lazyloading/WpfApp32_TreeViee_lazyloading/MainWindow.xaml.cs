﻿using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private static readonly string bucketName = "minquytbc1";
        private static readonly RegionEndpoint bucketRegion = RegionEndpoint.USEast1;
        private static IAmazonS3 s3Client;

        public MainWindow()
        {
            InitializeComponent();
            s3Client = new AmazonS3Client(bucketRegion);
            DriveInfo[] driveInfos = DriveInfo.GetDrives();
            foreach (DriveInfo driveInfo in driveInfos)
            {
                TrvStrucTure.Items.Add(CreateTreeItem(driveInfo));
            }
        }

        private async Task ListFiles()
        {
            try
            {
                var request = new ListObjectsV2Request
                {
                    BucketName = bucketName
                };
                ListObjectsV2Response response;
                do
                {
                    response = await s3Client.ListObjectsV2Async(request);
                    foreach (S3Object entry in response.S3Objects)
                    {
                        Console.WriteLine($"key = {entry.Key} size = {entry.Size}");
                    }
                    request.ContinuationToken = response.NextContinuationToken;
                } while (response.IsTruncated);
            }
            catch (AmazonS3Exception e)
            {
                MessageBox.Show($"Lỗi gặp phải trên máy chủ. Thông báo: '{e.Message}'");
            }
            catch (Exception e)
            {
                MessageBox.Show($"Lỗi không xác định trên máy chủ. Thông báo: '{e.Message}'");
            }
        }

        private async Task UploadFile(string filePath, string keyName)
        {
            try
            {
                var fileTransferUtility = new TransferUtility(s3Client);
                await fileTransferUtility.UploadAsync(filePath, bucketName, keyName);
                MessageBox.Show("Tải lên hoàn thành");
            }
            catch (AmazonS3Exception e)
            {
                MessageBox.Show($"Lỗi gặp phải trên máy chủ. Thông báo: '{e.Message}'");
            }
            catch (Exception e)
            {
                MessageBox.Show($"Lỗi không xác định trên máy chủ. Thông báo: '{e.Message}'");
            }
        }

        private async Task DownloadFile(string keyName, string destinationPath)
        {
            try
            {
                var request = new GetObjectRequest
                {
                    BucketName = bucketName,
                    Key = keyName
                };
                using (GetObjectResponse response = await s3Client.GetObjectAsync(request))
                using (Stream responseStream = response.ResponseStream)
                using (FileStream fileStream = new FileStream(destinationPath, FileMode.Create, FileAccess.Write))
                {
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = responseStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        fileStream.Write(buffer, 0, bytesRead);
                    }
                }
                MessageBox.Show("Tải xuống hoàn thành");
            }
            catch (AmazonS3Exception e)
            {
                MessageBox.Show($"Lỗi gặp phải trên máy chủ. Thông báo: '{e.Message}'");
            }
            catch (Exception e)
            {
                MessageBox.Show($"Lỗi không xác định trên máy chủ. Thông báo: '{e.Message}'");
            }
        }

        private async Task DeleteFile(string keyName)
        {
            try
            {
                var deleteObjectRequest = new DeleteObjectRequest
                {
                    BucketName = bucketName,
                    Key = keyName
                };
                await s3Client.DeleteObjectAsync(deleteObjectRequest);
                MessageBox.Show("Xóa hoàn thành");
            }
            catch (AmazonS3Exception e)
            {
                MessageBox.Show($"Lỗi gặp phải trên máy chủ. Thông báo: '{e.Message}'");
            }
            catch (Exception e)
            {
                MessageBox.Show($"Lỗi không xác định trên máy chủ. Thông báo: '{e.Message}'");
            }
        }

        private async Task RenameFile(string oldKeyName, string newKeyName)
        {
            try
            {
                var copyRequest = new CopyObjectRequest
                {
                    SourceBucket = bucketName,
                    SourceKey = oldKeyName,
                    DestinationBucket = bucketName,
                    DestinationKey = newKeyName
                };
                await s3Client.CopyObjectAsync(copyRequest);

                var deleteRequest = new DeleteObjectRequest
                {
                    BucketName = bucketName,
                    Key = oldKeyName
                };
                await s3Client.DeleteObjectAsync(deleteRequest);
                MessageBox.Show("Đổi tên hoàn thành");
            }
            catch (AmazonS3Exception e)
            {
                MessageBox.Show($"Lỗi gặp phải trên máy chủ. Thông báo: '{e.Message}'");
            }
            catch (Exception e)
            {
                MessageBox.Show($"Lỗi không xác định trên máy chủ. Thông báo: '{e.Message}'");
            }
        }

        private async void btnconnect_Click(object sender, RoutedEventArgs e)
        {
            await ListFiles();
        }

        private async void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            var filePath = "duong-dan-den-file-cua-ban";
            var keyName = "ten-key-cua-ban";
            await UploadFile(filePath, keyName);
        }

        private async void btnDownload_Click(object sender, RoutedEventArgs e)
        {
            var keyName = "ten-key-cua-ban";
            var destinationPath = "duong-dan-den-noi-tai-ve";
            await DownloadFile(keyName, destinationPath);
        }

        private async void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var keyName = "ten-key-cua-ban";
            await DeleteFile(keyName);
        }

        private async void btnRename_Click(object sender, RoutedEventArgs e)
        {
            var oldKeyName = "ten-key-cu-cua-ban";
            var newKeyName = "ten-key-moi-cua-ban";
            await RenameFile(oldKeyName, newKeyName);
        }

        private void txtFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
        }

        private void TrvStrucTure_Expanded(object sender, RoutedEventArgs e)
        {
            TreeViewItem item = e.Source as TreeViewItem;
            if ((item.Items.Count == 1) && (item.Items[0] is string))
            {
                item.Items.Clear();

                DirectoryInfo expandedDir = null;
                if (item.Tag is DriveInfo)
                {
                    expandedDir = (item.Tag as DriveInfo).RootDirectory;
                }
                else if (item.Tag is DirectoryInfo)
                {
                    expandedDir = (item.Tag as DirectoryInfo);
                }
                try
                {
                    foreach (DirectoryInfo subDir in expandedDir.GetDirectories())
                    {
                        item.Items.Add(CreateTreeItem(subDir));
                    }
                }
                catch (Exception ex) { }
            }
        }

        private TreeViewItem CreateTreeItem(object o)
        {
            TreeViewItem item = new TreeViewItem();
            item.Header = o.ToString();
            item.Tag = o;
            item.Items.Add("Đang tải...");
            return item;
        }

        private void btnDisconnect_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
