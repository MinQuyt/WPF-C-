﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfApp13_Canvas
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
