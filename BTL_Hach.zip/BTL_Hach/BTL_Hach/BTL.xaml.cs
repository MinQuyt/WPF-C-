﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BTL_Hach
{
    /// <summary>
    /// Interaction logic for BTL.xaml
    /// </summary>
    public partial class BTL : Window
    {
        public BTL()
        {
            InitializeComponent();
        }

        // Hàm xử lý nút "Chọn File"
        private void ChooseFileButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                InputTextBox.Text = File.ReadAllText(openFileDialog.FileName, Encoding.UTF8);
            }
        }

        // Hàm xử lý nút "Kiểm Tra Tính Toàn Vẹn"
        private void CheckIntegrityButton_Click(object sender, RoutedEventArgs e)
        {
            string inputText = InputTextBox.Text;

            if (string.IsNullOrWhiteSpace(inputText))
            {
                MessageBox.Show("Vui lòng nhập văn bản hoặc chọn file!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string sha512Hash = ComputeSHA512Hash(inputText);
            ResultTextBox.Text = sha512Hash;
        }

        // Hàm tính SHA-512
        private string ComputeSHA512Hash(string input)
        {
            using (SHA512 sha512 = SHA512.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = sha512.ComputeHash(inputBytes);

                // Chuyển đổi sang chuỗi Hex
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    sb.Append(b.ToString("x2"));
                }
                return sb.ToString();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            Close();
            mainWindow.Show();
        }
    }
}