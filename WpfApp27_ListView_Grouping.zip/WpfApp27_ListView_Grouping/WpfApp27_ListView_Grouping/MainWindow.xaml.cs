﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static WpfApp27_ListView_Grouping.MainWindow;

namespace WpfApp27_ListView_Grouping
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public enum sextype { Male,FeMale};
        public MainWindow()
        {
            InitializeComponent();
            List<User> ListUser = new List<User>();

            ListUser.Add(new User() { Name = "Chan minh quyt", Age = 21, Mail = "tquyhb@gmail.com",Sex=sextype.Male });
            ListUser.Add(new User() { Name = "hello min quy", Age = 22, Mail = "quydzxx@gmail.com", Sex=sextype.FeMale});
            ListUser.Add(new User() { Name = "quý chan hb", Age = 20, Mail = "deptrai@gmail.com", Sex=sextype.Male});

            lvUser.ItemsSource = ListUser;

            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(lvUser.ItemsSource);
            PropertyGroupDescription propertyGroupDescription = new PropertyGroupDescription("Sex");
            view.GroupDescriptions.Add(propertyGroupDescription);   
        }
        public class User
        {
            public string Name { get; set; }
            public int Age { get; set; }
            public string Mail { get; set; }
            public sextype Sex { get; set; }
        }
    }
}