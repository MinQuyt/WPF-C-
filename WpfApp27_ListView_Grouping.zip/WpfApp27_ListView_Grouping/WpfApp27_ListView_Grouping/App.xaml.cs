﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfApp27_ListView_Grouping
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
