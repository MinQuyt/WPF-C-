﻿using System.ComponentModel;
using System.Text;
using System.Windows;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp6_Binding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private String buttonName;
        public String ButtonName
        {
            get { return buttonName; }
            set
            {
                buttonName = value;
                onPropertyChanged("ButtonName");
            }
        }
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
            ButtonName = "Data from window code bihind";
        }
        public event PropertyChangedEventHandler  PropertyChanged;
        protected virtual void onPropertyChanged(string newName)
        {
            if(PropertyChanged != null) 
            { 
            PropertyChanged(this, new PropertyChangedEventArgs(newName));
            }
        }

        private void txboxSource_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        //private void btnBinding_Click(object sender, RoutedEventArgs e)
        //{
        //    txblBinding.Text=txblSource.Text;
        //}
    }
}