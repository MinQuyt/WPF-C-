﻿using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp29_ListView_Filtering
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public bool isSort = false;
        public MainWindow()
        {
            InitializeComponent();
            List<User> items = new List<User>();
            items.Add(new User() { Name = "hello min quyt", Age = 42, Sex = SexType.Male });
            items.Add(new User() { Name = "Chào quý nha", Age = 39, Sex = SexType.Female });
            items.Add(new User() { Name = "lmao lmao dark dark burh burh ", Age = 13, Sex = SexType.Male });
            items.Add(new User() { Name = "em chã ", Age = 13, Sex = SexType.Female });
            lvUsers.ItemsSource = items;

            ////hiển thị sort dữ liệu 
            //    CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(lvUsers.ItemsSource);
            ////Accending la sort theo từ thấp xuống cao và ngược lại Decending là từ cao xuống thấp
            //view.SortDescriptions.Add(new SortDescription("Age",ListSortDirection.Ascending));
            //view.SortDescriptions.Add(new SortDescription("Name",ListSortDirection.Ascending));

            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(lvUsers.ItemsSource);
            view.Filter = UserFilter;
        }

        private bool UserFilter(object item)
        {
            if (string.IsNullOrEmpty(txtFilter.Text))
                return true;
            else
                return (item as User).Name.IndexOf(txtFilter.Text, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void TxtFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(lvUsers.ItemsSource).Refresh();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //hiển thị sort dữ liệu 
            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(lvUsers.ItemsSource);
            //Accending la sort theo từ thấp xuống cao và ngược lại Decending là từ cao xuống thấp
            if (isSort)
            {
                view.SortDescriptions.Clear();

                view.SortDescriptions.Add(new SortDescription("Age", ListSortDirection.Ascending));
            }
            else
            {
                view.SortDescriptions.Clear();
                view.SortDescriptions.Add(new SortDescription("Age", ListSortDirection.Descending));
            }
            isSort = !isSort;

        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(lvUsers.ItemsSource);
            //Accending la sort theo từ thấp xuống cao và ngược lại Decending là từ cao xuống thấp
            if (isSort)
            {
                view.SortDescriptions.Clear();

                view.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
            }
            else
            {
                view.SortDescriptions.Clear();

                view.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Descending));
            }
            isSort = !isSort;

        }


        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(lvUsers.ItemsSource);
            //Accending la sort theo từ thấp xuống cao và ngược lại Decending là từ cao xuống thấp
            if (isSort)
            {
                view.SortDescriptions.Clear();
                view.SortDescriptions.Add(new SortDescription("Mail", ListSortDirection.Ascending));
            }
            else
            {
                view.SortDescriptions.Clear();

                view.SortDescriptions.Add(new SortDescription("Mail", ListSortDirection.Descending));
            }
            isSort = !isSort;

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(lvUsers.ItemsSource);
            //Accending la sort theo từ thấp xuống cao và ngược lại Decending là từ cao xuống thấp
            if (isSort)
            {
                view.SortDescriptions.Clear();

                view.SortDescriptions.Add(new SortDescription("Sex", ListSortDirection.Ascending));
            }
            else
            {
                view.SortDescriptions.Clear();

                view.SortDescriptions.Add(new SortDescription("Sex", ListSortDirection.Descending));
            }
            isSort = !isSort;

        }
    }

    public enum SexType { Male, Female };

    public class User
    {
        public string Name { get; set; }

        public int Age { get; set; }

        public string Mail { get; set; }

        public SexType Sex { get; set; }
    }
}